<?php

$res = 1;

?>