<?php

if($_POST)
{
	$name    = $_POST['name'];
	$email   = $_POST['email'];
	$phone   = $_POST['phone'];
	$signup  = $_POST['signup'];
	$city    = $_POST['city'];
	$message = $_POST['message'];
	?>
    
    <table border="0">
    
    <tr>
    <td colspan="2">You are Registered Successfully!</td>
    </tr>
    
    <tr>
    <td>Name</td>
    <td><?php echo $name ?></td>
    </tr>
    
    <tr>
    <td>Email</td>
    <td><?php echo $email?></td>
    </tr>
    
    <tr>
    <td>Phone</td>
    <td><?php echo $phone ?></td>
    </tr>
    
    <tr>
    <td>Signup</td>
    <td><?php echo $signup; ?></td>
    </tr>
    
    <tr>
    <td>City</td>
    <td><?php echo $city; ?></td>
    </tr>
    
    <tr>
    <td>Your Message</td>
    <td><?php echo $message; ?></td>
    </tr>
    
    </table>
    <?php
	
}

?>