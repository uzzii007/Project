
// sticky header
$(window).scroll(function() {    
var scroll = $(window).scrollTop();
//>=, not <=
if (scroll >= 800) {
//clearHeader, not clearheader - caps H
$(".float-btn").addClass("sticku");
} else {
$(".float-btn").removeClass("sticku");  
}
});
// sticky header end


              

// sticky social
$(document).scroll(function () {
    var y = $(this).scrollTop();
    if (y > 300) {
        $('.float-btn').fadeIn();
    } else {
        $('.float-btn').fadeOut();
    }

}); 
// sticky social end

$(document).ready(function() {
	


  var input = document.querySelector("#phone");
window.intlTelInput(input);

var input = document.querySelector("#phone1");
window.intlTelInput(input);


$('.slider-home-main').slick({
    dots: true,
    arrows: false,
    vertical: true,
    slidesToShow: 1,
    slidesToScroll: 1,
  autoplay:true,
    verticalSwiping: true,
  });

$('.pofoloi-slider').slick({
    dots: true,
    arrows: true,
    slidesToShow: 1,
    slidesToScroll: 1,
  autoplay:true,
      responsive: [
{
breakpoint: 1023,
settings:{arrows:false,}
},

]
 
    
  });

/*mob-menu start*/

$("header .mob-menu-icon").on('click',function(){
    $('body').toggleClass('show-menu');
});

$('.mob-menu .closebtn').on('click',function(){
   $('body').removeClass('show-menu');

});

$('.menu-mobile>ul>li').on('click',function(){
   $(this).children('ul').slideToggle();
   
});

/*mob-menu End*/





$('.testimonial-slider').slick({
    dots: true,
    arrows: false,
    slidesToShow: 3,
    slidesToScroll: 1,
  autoplay:true,
      responsive: [
{
breakpoint: 767,
settings:{slidesToShow:1, slidesToScroll:1}
},

]
    
  });




$(".sliderxs").slick({
arrows: false,
dots: true,
autoplay: true,
slidesToShow:1,
slidesToScroll: 1,
adaptiveHeight: true,
responsive: [
{
breakpoint: 2000,
settings: "unslick"
},
{
breakpoint: 767,
settings: {
unslick: true
}
}
]
});


//floating-form
    $('body').on('click', '.floatForm .switch', function () {
        $('body').toggleClass('showPop');
    }).on('click', '.backdrop', function () {
        $('body').removeClass('showPop');
    });

    $(window).scroll(function (e) {
        var scroll = $(window).scrollTop();
        console.log(scroll);
    });
//end    

// Active Current Page
$(function () {
setNavigation();
});
function setNavigation() {
var path = window.location.pathname;
path = path.replace(/\/$/, "");
path = decodeURIComponent(path);
$(".top-nav a").each(function () {
var href = $(this).attr('href');
if (path.substring(0, href.length) === href) {
$(this).closest('li a').addClass('active');
}
});
}
// Active Current Page end



////// Accordion 
$('.accordion .quest-title.active1').addClass('active');
$('#accordion-1').slideDown(300).addClass('open');
function close_accordion_section() {
jQuery('.accordion .quest-title').removeClass('active');
jQuery('.accordion .quest-content').slideUp(300).removeClass('open');
}
jQuery('.quest-title').click(function(e) {
// Grab current anchor value
var currentAttrValue = jQuery(this).attr('href');
if(jQuery(e.target).is('.active')) {
close_accordion_section();
}else {
close_accordion_section();
// Add active class to section title
jQuery(this).addClass('active');
// Open up the hidden content panel
jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open'); 
}
e.preventDefault();
});
////// Accordion end 


 
////// footer year
$(function(){
var theYear = new Date().getFullYear();
$('#year').html(theYear);
});	








});


		
 /* Cracker JS */